#!/bin/sh
#sudo mkdir /usr/local/apache-maven/
#cd /usr/local/apache-maven/
#sudo wget http://ftp.byfly.by/pub/apache.org/maven/maven-3/3.5.2/binaries/apache-maven-3.5.2-bin.tar.gz
#sudo tar -xvf apache-maven-3.5.2-bin.tar.gz
#export M2_HOME=/usr/local/apache-maven/apache-maven-3.5.2
#export M2=$M2_HOME/bin
#export PATH=$M2:$PATH
#export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-1.b12.el7_4.x86_64/jre
#export PATH=$JAVA_HOME/bin:$PATH
#export MAVEN_OPTS="-Xms256m -Xmx512m"
sudo yum -y install maven
mvn --version
